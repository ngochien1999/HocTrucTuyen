﻿namespace FisrtApplication
{
    public interface IWebHostEnvironment
    {
        bool IsDevelopment();
    }
}